def main():
    with open("kuis.txt", "r") as file:
        for line in file:
            kuis, jawaban = line.strip().split(" || ")
            
            print("Pertanyaan:\n")
            print(kuis)
            
            jawab = input("Jawab: ").lower().strip()
            
            if jawab == jawaban.lower().strip():
                print("Jawaban Anda benar!")
            else:
                print(f"Jawaban Anda salah! Jawaban yang benar adalah: {jawaban}")

main()

