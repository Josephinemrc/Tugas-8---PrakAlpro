file1 = open("file1.txt").readlines()
file2 = open("file2.txt").readlines()
baris = max(len(file1), len(file2))

for i in range(baris):
    if i < len(file1) and i < len(file2):
        if file1[i] == file2 [i]:
            print(f"kata pada baris ke-{i+1} sama pada kedua file")
        else :
            print(f"kata pada baris ke- {i+1} tidak sama.")
            print(f"dua kata tersebut ada perbedaan pada {file1[i]} di file pertama dan {file2[i]} di file kedua")
            
            
            








